﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace petStore.Website.Components
{
    public class Cart
    {
        public static List<Tuple<string,string,string,string>> items=new List<Tuple<string,string, string, string>>();
      

    }
}
