﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using petStore.Website.Services;
using petStore.Website.Models;
namespace petStore.Website.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class OverviewController : Controller
    {
        public JsonFilePetService PetService { get; }
        public OverviewController(JsonFilePetService petService)
        {
            this.PetService = petService;
        }
        public IActionResult Overview()
        {
            return View();
        }
    }
}
