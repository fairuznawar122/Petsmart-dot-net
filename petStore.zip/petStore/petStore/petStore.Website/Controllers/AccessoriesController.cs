﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using petStore.Website.Services;

namespace petStore.Website.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AccessoriesController : Controller
    {
        public JsonFileAccessoriesService AccessoriesService { get; }
        public AccessoriesController(JsonFileAccessoriesService accessoriesService)
        {
            this.AccessoriesService = accessoriesService;
        }
        public IActionResult Accessories()
        {
            return View();
        }
    }
}
