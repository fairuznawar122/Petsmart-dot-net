﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using petStore.Website.Models;
using petStore.Website.Services;

namespace petStore.Website.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PetsController : Controller
    {
        public JsonFilePetService PetService { get; }
        public PetsController (JsonFilePetService petService)
        {
            this.PetService = petService;
        }
       
       /* public IEnumerable<pet> Get()
        {
            return PetService.GetProducts();
        }*/


        public IActionResult Pets()
        {
            return View();
        }
        
    }
    
}
