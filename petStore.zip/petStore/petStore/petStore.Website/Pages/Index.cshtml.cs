﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using petStore.Website.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using petStore.Website.Models;

namespace petStore.Website.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        public JsonFilePetService petService;
        public IEnumerable<pet> pets { get; private set; }
        public IndexModel(ILogger<IndexModel> logger,JsonFilePetService petService)
        {
            _logger = logger;
            this.petService = petService;
        }

        public void OnGet()
        {
            pets = petService.GetProducts();
        }
    }
}
