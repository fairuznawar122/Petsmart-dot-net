﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

using Microsoft.AspNetCore.Hosting;
using petStore.Website.Models;

namespace petStore.Website.Services
{
    public class JsonFilePetService
    {
        public JsonFilePetService(IWebHostEnvironment webHostEnvironment)
        {
            WebHostEnvironment = webHostEnvironment;
        }

        public IWebHostEnvironment WebHostEnvironment { get; }

        private string JsonFileName
        {
            get { return Path.Combine(WebHostEnvironment.WebRootPath, "data", "pets.json"); }
        }

        public IEnumerable<pet> GetProducts()
        {
            using (var jsonFileReader = File.OpenText(JsonFileName))
            {
                return JsonSerializer.Deserialize<pet[]>(jsonFileReader.ReadToEnd(),
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
            }
        }

    }
    

}