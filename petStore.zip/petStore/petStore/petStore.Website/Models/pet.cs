﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace petStore.Website.Models
{
    public class pet
    {
        public string pet_id { get; set; }
        public string pet_breed { get; set; }
        public string pet_url { get; set; }
        public string pet_category { get; set; }
        public string pet_color { get; set; }
        public string pet_weight { get; set; }
        public string pet_age { get; set; }
        public string pet_description { get; set; }
        public string pet_price { get; set; }
        public string pet_unit { get; set; }

        public override string ToString() => JsonSerializer.Serialize<pet>(this);
    }

}
