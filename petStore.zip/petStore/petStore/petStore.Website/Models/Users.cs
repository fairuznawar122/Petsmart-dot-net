﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace petStore.Website.Models
{
    public class Users
    {
        public string user_id { get; set; }
        public string user_name { get; set; }
        public string user_password { get; set; }
        public string user_phone { get; set; }
        public string user_address { get; set; }
        public string user_email { get; set; }
        //public override string ToString() => JsonSerializer.Serialize<Users>(this);
    }
}
