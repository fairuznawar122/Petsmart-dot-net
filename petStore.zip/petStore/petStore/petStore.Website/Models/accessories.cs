﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace petStore.Website.Models
{
    public class accessories
    {
        public string product_id { get; set; }
        public string product_name { get; set; }
        public string product_used_for { get; set; }
        public string product_price { get; set; }
        public string product_category{ get; set; }
        public string product_quantity{ get; set; }
        public string product_url { get; set; }


        public override string ToString() => JsonSerializer.Serialize<accessories>(this);
    }
}
