﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace petStore.Website.Models
{
    public class Orders
    {
        public string customer_id { get; set; }
        public List<Tuple<string,string,string,string>> items { get; set; }

        public string status { get; set; }
    }
}
